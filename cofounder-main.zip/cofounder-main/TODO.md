A non-ordered roadmap & todo dump
will update with proper map later, ignore for now

---

## nearest
merge with browser-based local dev env using webcontainers ; console.cofounder.openinterface.ai

## validation, errorfix
post-generation validation swarm modules
swarm autofix modules, merge
babel parse

## build, deploy
vite plugin to generate web app without the cofounder modules
generate packed projects ready for deployment
automate deployments, integrate different services

## design, layouts
plug in advanced designer + models
document how to custom design systems
add & index docs for shiny design systems
fonts / css modules
release extensive cofounder index on api access for layout designer to use
separate {desktop,mobile} in designer
RAG on icons via {text/clip} (like in openv0), maybe as a vite plugin

## functional
deploy latest index checkpoint in api.cofounder

## mgmt
more iteration modules, sequences to handle full lifecycle of generated projects
document everything

## platforms
react-native / flutter
more frontend frameworks

## project
technical articles
model train & serve from api
admin panel à la coolify

## also
SEO stuff
analytics into the dev feedback
animation (ie. framer-motion)
functional, api, python support api-side
benchmarks