## Notes

This is a demo design system and will be replaced on official post-alpha release

## Credits

Renders dumped from Figma Presets:

- Blocks.pm by Hexa Plugin
- Google Material & Figma Core Design systems
