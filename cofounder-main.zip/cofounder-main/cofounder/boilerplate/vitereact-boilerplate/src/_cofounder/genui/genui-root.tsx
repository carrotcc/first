/*
  in all components, for better ux for customers:
    > firestore subscriptions will {mkdir ui components + write meta.json} the second they are starting to generate
    > just like in infragenui, have loaders to show, but instead of calling on not found/not working, only call on not working
*/
