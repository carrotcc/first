app generated from cofounder/boilerplate

instructions here on how to start api and frontend , whether in parallel or separately