import React from "react";

const Settings: React.FC = () => {
	return (
		<div className="flex items-center justify-center h-screen w-full text-white">
			<h1 className="text-2xl font-light opacity-50 text-center">{`{ settings : not implemented yet }`}</h1>
		</div>
	);
};

export default Settings;
