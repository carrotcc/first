import React, { useCallback, useState, useEffect } from "react";
import App from "@/App.tsx";

const AppWrapper: React.FC = () => {
	return (
		<>
			{/*<Cmdl />*/}
			<App />
		</>
	);
};

export default AppWrapper;
